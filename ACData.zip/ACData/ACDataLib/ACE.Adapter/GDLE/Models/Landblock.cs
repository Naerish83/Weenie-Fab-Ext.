namespace ACE.Adapter.GDLE.Models
{
    public class Landblock
    {
        public uint key { get; set; }
        public LandblockValue value { get; set; }
        public string desc { get; set; }
    }
}
