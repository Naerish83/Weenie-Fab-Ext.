namespace ACE.Adapter.GDLE.Models
{
    public class Position
    {
        public Frame frame { get; set; }
        public uint objcell_id { get; set; }
    }
}
