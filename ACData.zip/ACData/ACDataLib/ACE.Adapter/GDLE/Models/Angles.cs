namespace ACE.Adapter.GDLE.Models
{
    public class Angles
    {
        public float w { get; set; }
        public float x { get; set; }
        public float y { get; set; }
        public float z { get; set; }
    }
}
