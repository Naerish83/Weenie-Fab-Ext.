namespace ACE.Adapter.GDLE.Models
{
    public class Quest
    {
        public string key { get; set; }
        public QuestValue value { get; set; }
    }
}
