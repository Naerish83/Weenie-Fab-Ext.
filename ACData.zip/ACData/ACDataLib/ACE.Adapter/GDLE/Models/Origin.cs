namespace ACE.Adapter.GDLE.Models
{
    public class Origin
    {
        public float x { get; set; }
        public float y { get; set; }
        public float z { get; set; }
    }
}
