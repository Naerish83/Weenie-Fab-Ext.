﻿namespace ACE.Adapter.GDLE.Models
{
    public class LandblockWeenie
    {
        public uint id { get; set; }
        public uint wcid { get; set; }
        public string desc { get; set; }
        public Position pos { get; set; }
    }
}
