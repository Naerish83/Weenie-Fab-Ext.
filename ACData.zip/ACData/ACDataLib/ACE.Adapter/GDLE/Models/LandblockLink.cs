namespace ACE.Adapter.GDLE.Models
{
    public class LandblockLink
    {
        public uint target { get; set; }
        public uint source { get; set; }
        public string desc { get; set; }
    }
}
