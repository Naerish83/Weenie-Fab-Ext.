
namespace ACE.Entity.Enum
{
    public enum HouseType
    {
        Undef,
        Cottage,
        Villa,
        Mansion,
        Apartment
    }
}
