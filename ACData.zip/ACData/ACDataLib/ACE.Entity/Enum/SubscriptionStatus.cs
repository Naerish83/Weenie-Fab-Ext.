
namespace ACE.Entity.Enum
{
    public enum SubscriptionStatus
    {
        No_Subscription,
        AsheronsCall_Subscription,
        DarkMajesty_Subscription,
        ThroneOfDestiny_Subscription,
        ThroneOfDestiny_Preordered
    }
}
