namespace ACE.Entity.Enum
{
    public enum GeneratorType
    {
        Undef,
        Relative,
        Absolute
    }
}
