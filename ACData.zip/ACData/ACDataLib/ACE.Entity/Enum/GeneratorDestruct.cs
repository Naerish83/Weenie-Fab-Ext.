namespace ACE.Entity.Enum
{
    public enum GeneratorDestruct
    {
        Undef,
        Nothing,
        Destroy,
        Kill
    }
}
