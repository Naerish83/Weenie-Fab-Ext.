
namespace ACE.Entity.Enum
{
    public enum SummoningMastery
    {
        Undef,
        Primalist,
        Necromancer,
        Naturalist
    }
}
