namespace ACE.Entity.Enum
{
    public enum RecipeSourceType
    {
        Player  = 0,
        Source  = 1,
        Dye     = 60
    };
}
