namespace ACE.Entity.Enum
{
    public enum RequirementType
    {
        Target = 0,
        Source = 1,
        Player = 2
    };
}
