
namespace ACE.Entity.Enum
{
    public enum SkillAdvancementClass : uint
    {
        Inactive,
        Untrained,
        Trained,
        Specialized
    }
}
