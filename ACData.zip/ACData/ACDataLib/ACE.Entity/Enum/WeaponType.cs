
namespace ACE.Entity.Enum
{
    public enum WeaponType
    {
        Undef,
        Unarmed,
        Sword,
        Axe,
        Mace,
        Spear,
        Dagger,
        Staff,
        Bow,
        Crossbow,
        Thrown,
        TwoHanded,
        Magic
    }
}
