﻿namespace ACE.Entity.Enum
{
    public enum RadarBehavior : byte
    {
        Undefined           = 0,
        ShowNever           = 1,
        ShowMovement        = 2,
        ShowAttacking       = 3,
        ShowAlways          = 4
    }
}
