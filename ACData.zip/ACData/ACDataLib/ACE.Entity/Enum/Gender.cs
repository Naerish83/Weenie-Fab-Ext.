namespace ACE.Entity.Enum
 {
     public enum Gender
     {
         Invalid = 0,
         Male    = 1,
         Female  = 2
     }
 }
