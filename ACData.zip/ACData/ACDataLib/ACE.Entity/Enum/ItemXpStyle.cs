
namespace ACE.Entity.Enum
{
    public enum ItemXpStyle
    {
        Undef,
        Fixed,
        ScalesWithLevel,
        FixedPlusBase   // unused?
    }
}
