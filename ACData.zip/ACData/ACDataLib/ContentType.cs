﻿namespace ACDataLib
{
    public enum ContentType
    {
        Undefined,
        Landblock,
        Quest,
        Recipe,
        Weenie,
    }
}
