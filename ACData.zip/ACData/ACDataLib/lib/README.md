The included ACE DLL files are AGPLv3 licensed.
The source code can be found here: https://github.com/ACEmulator/ACE

ACE.Adapter.dll
ACE.Common.dll
ACE.Entity.dll
ACE.Database.dll

The included Lifestoned DLL files are MIT licensed.
The source code can be found here: https://gitlab.com/Scribble/lifestoned

Lifestoned.DataModel.dll
