﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class CloseMe : Emote
    {
        public CloseMe() : base(EmoteType.CloseMe)
        {

        }
    }
}
