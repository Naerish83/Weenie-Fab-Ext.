﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class TurnToTarget : Emote
    {
        public TurnToTarget() : base(EmoteType.TurnToTarget)
        {

        }
    }
}
