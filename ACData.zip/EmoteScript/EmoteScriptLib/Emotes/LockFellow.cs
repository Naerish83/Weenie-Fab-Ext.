﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class LockFellow : Emote
    {
        public LockFellow() : base(EmoteType.LockFellow)
        {

        }
    }
}
