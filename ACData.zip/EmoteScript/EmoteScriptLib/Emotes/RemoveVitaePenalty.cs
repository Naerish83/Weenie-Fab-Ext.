﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class RemoveVitaePenalty : Emote
    {
        public RemoveVitaePenalty() : base(EmoteType.RemoveVitaePenalty)
        {

        }
    }
}
