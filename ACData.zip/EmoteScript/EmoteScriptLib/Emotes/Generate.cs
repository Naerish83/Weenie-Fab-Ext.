﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class Generate : Emote
    {
        public Generate() : base(EmoteType.Generate)
        {

        }
    }
}
