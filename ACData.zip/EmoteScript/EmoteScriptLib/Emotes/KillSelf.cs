﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class KillSelf : Emote
    {
        public KillSelf() : base(EmoteType.KillSelf)
        {

        }
    }
}
