﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class BLog : Emote
    {
        public BLog() : base(EmoteType.BLog)
        {

        }
    }
}
