﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class ResetHomePosition : Emote
    {
        public ResetHomePosition() : base(EmoteType.ResetHomePosition)
        {

        }
    }
}
