﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class Activate : Emote
    {
        public Activate() : base(EmoteType.Activate)
        {

        }
    }
}
