﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class StartBarber : Emote
    {
        public StartBarber() : base(EmoteType.StartBarber)
        {

        }
    }
}
