﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class OpenMe : Emote
    {
        public OpenMe() : base(EmoteType.OpenMe)
        {

        }
    }
}
