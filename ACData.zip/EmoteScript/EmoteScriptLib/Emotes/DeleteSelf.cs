﻿using EmoteScriptLib.Entity.Enum;

namespace EmoteScriptLib.Emotes
{
    public class DeleteSelf : Emote
    {
        public DeleteSelf() : base(EmoteType.DeleteSelf)
        {

        }
    }
}
