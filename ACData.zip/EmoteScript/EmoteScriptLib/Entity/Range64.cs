﻿namespace EmoteScriptLib
{
    public class Range64
    {
        public long? Min;
        public long? Max;

        public Range64(long? min, long? max)
        {
            Min = min;
            Max = max;
        }
    }
}
