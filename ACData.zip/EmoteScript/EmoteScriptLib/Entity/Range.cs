﻿namespace EmoteScriptLib
{
    public class Range
    {
        public int? Min;
        public int? Max;

        public Range(int? min, int? max)
        {
            Min = min;
            Max = max;
        }
    }
}
