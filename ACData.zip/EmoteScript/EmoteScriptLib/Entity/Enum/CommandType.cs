﻿namespace EmoteScriptLib
{
    public enum CommandType
    {
        None,
        Emote,
        EmoteSet,
    }
}
