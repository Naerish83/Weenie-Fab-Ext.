﻿namespace EmoteScriptLib.Entity.Enum
{
    public enum RangeType
    {
        Min,
        Max
    }
}
