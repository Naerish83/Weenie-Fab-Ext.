# EmoteScript
A simple scripting language for Asheron's Call emotes

Usage: EmoteScript &lt;filename&gt;

Converts an EmoteScript file into a sql/json file

Example:

.es input file:<br />
https://github.com/gmriggs/EmoteScript/blob/master/EmoteScript.Tests/Scripts/cow.es

.sql output:<br />
https://github.com/gmriggs/EmoteScript/blob/master/EmoteScript.Tests/Scripts/cow.sql

.json output:<br />
https://github.com/gmriggs/EmoteScript/blob/master/EmoteScript.Tests/Scripts/cow.json
